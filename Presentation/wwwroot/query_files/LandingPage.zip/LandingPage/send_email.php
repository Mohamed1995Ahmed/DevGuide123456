<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // Make sure this path is correct for the PHPMailer autoload
if ($_SERVER["REQUEST_METHOD"] == "POST")
 {
    // Retrieve form data
    $name = htmlspecialchars(trim($_POST['name']));
    $phone = htmlspecialchars(trim($_POST['phone']));
    $service = $_POST['service'] ?? '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    // echo "<script>alert('Selected Service: $service') </script>"; 
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'usmanfallatah@gmail.com'; // Your Gmail address
        $mail->Password   = 'mznhoifbstsgpwby'; // Your App Password if using 2-Step Verification
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        // Recipients
        $mail->setFrom($email, $name); // Your email and name
        $mail->addAddress('usmanfallatah@gmail.com', 'Recipient Name'); // Recipient email and name

        // Content
        $mail->isHTML(true);
        $mail->CharSet = 'UTF-8';
        $mail->Subject = "خدمات بيت الخبرة العقارية";
        $serviceText = $service ? "$service" : "No service selected.";
        $mail->Body    = "<b>Name:</b> $name <br>
                          <b>Email:</b> $email <br>
                          <b>Phone:</b> $phone <br>
                          <b>service:</b> $serviceText <br>";
        $mail->send();
        echo 'Message has been sent';
    } 
    catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
} 
else {
    echo "Invalid request.";
}
?>
