// script.js

document.getElementById('contactForm').addEventListener('submit', function (event) {
    event.preventDefault();  // Prevent the default form submission

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    const service = document.getElementById('service').value;

    // Validate form fields
    if (name === "" || email === "" || phone === "" || service === "") {
        alert("Please fill out all fields.");
        return;
    } else if (!validateEmail(email)) {
        alert("Please enter a valid email address.");
        return;
    }

    // Send form data using AJAX
    fetch('http://localhost:8012/LandingPage/send_email.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `name=${encodeURIComponent(name)}&email=${encodeURIComponent(email)}&phone=${encodeURIComponent(phone)}&service=${encodeURIComponent(service)}`
    })
        .then(response => response.text())
        .then(responseText => {
            alert(responseText);  // Display server response
            document.getElementById('contactForm').reset();  // Reset the form
        })
        .catch(error => console.error('Error:', error));
});

// Function to validate email format
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function openWhatsApp() {
    const phoneNumber = '1122001912'; // Replace with your phone number in international format, no "+" or "-"
    const message = encodeURIComponent("Hello! I'd like to connect with you.");
    // const url = `https://wa.me/${phoneNumber}?text=${message}`;
    const url = `https://api.whatsapp.com/send?phone=${phoneNumber}&text=${message}`;
    // const url = `https://api.whatsapp.com/send?phone=${phoneNumber}&text=${message}`;
    // const url = 'whatsapp://send?text=This is WhatsApp sharing example using link'

    window.open(url, '_blank');
}

